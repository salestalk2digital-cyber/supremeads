import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { useCounter } from '../hooks/useCounter';

// ─── Hero Visual Elements ─────────────────────────────────────────────────────

function MetaLogo() {
  return (
    <svg viewBox="0 0 60 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
      <path d="M7.2 16C7.2 10.8 9.6 7.2 12.8 7.2C15.2 7.2 16.8 8.8 18.8 12L20 14L18.8 16C16.4 20 14.8 22 12.8 22C9.6 22 7.2 18.4 7.2 16Z" fill="#0866FF"/>
      <path d="M20 14L21.2 12C23.2 8.8 25.2 7.2 27.6 7.2C31.6 7.2 34.8 11.6 34.8 16C34.8 20.4 31.6 24.8 27.6 24.8C25.2 24.8 23.2 23.2 21.2 20L20 18L21.2 16L22.8 18.8C24.4 21.2 25.6 22.4 27.2 22.4C29.6 22.4 31.6 19.6 31.6 16C31.6 12.4 29.6 9.6 27.2 9.6C25.6 9.6 24.4 10.8 22.8 13.2L20 18L17.2 13.2C16 11.2 14.8 9.6 12.8 9.6C10.4 9.6 8.4 12.4 8.4 16C8.4 19.6 10.4 22.4 12.8 22.4C14.4 22.4 16 21.2 17.6 18.8L20 15.2L22.4 18.8C24 21.2 25.6 22.4 27.2 22.4C29.6 22.4 31.6 19.6 31.6 16C31.6 12.4 29.6 9.6 27.2 9.6C25.6 9.6 24.4 10.8 22.8 13.2L20 18" fill="#0866FF" opacity="0"/>
      <ellipse cx="12.8" cy="16" rx="5.6" ry="8.8" fill="#0866FF"/>
      <path d="M18.8 12C20.8 8.8 22.8 7.2 25.2 7.2C28.4 7.2 30.8 9.6 32.4 13.6C33.2 15.2 33.6 16.8 33.6 18.4C33.6 21.2 32 24.8 29.6 24.8C27.6 24.8 26 23.2 24 20L20 14L18.8 12Z" fill="#0099FF"/>
      <path d="M34.4 14C35.6 10.8 37.6 8 40 8C43.2 8 45.6 11.6 45.6 16C45.6 20.4 43.2 24 40 24C37.6 24 35.6 21.2 34.4 18" fill="#00C8FF"/>
      <ellipse cx="40" cy="16" rx="5.6" ry="8" fill="#00AAFF"/>
    </svg>
  );
}

function PhoneMockup() {
  return (
    <div className="relative w-44 rounded-[2rem] bg-midnight border border-white/10 overflow-hidden shadow-2xl shadow-black/40" style={{height: '340px'}}>
      {/* Phone notch */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 w-20 h-5 bg-black rounded-full z-10" />

      {/* Screen */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0F172A] to-[#1a2540] pt-10">
        {/* Meta app header */}
        <div className="px-3 py-2 flex items-center justify-between border-b border-white/5">
          <span className="text-white font-bold text-xs">Meta Ads</span>
          <div className="flex gap-1.5">
            <div className="w-4 h-4 rounded bg-meta-blue/30" />
            <div className="w-4 h-4 rounded bg-white/10" />
          </div>
        </div>

        {/* Campaign metric */}
        <div className="px-3 py-3">
          <div className="bg-white/5 rounded-lg p-2.5 mb-2">
            <p className="text-white/40 text-[8px] mb-1">REACH</p>
            <p className="text-white font-bold text-lg">2.4M</p>
            <div className="flex items-center gap-1 mt-1">
              <div className="w-full bg-white/10 rounded-full h-1">
                <div className="bg-meta-blue h-1 rounded-full w-3/4" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            {[
              { label: 'ROAS', value: '8.2x', color: 'text-green-400' },
              { label: 'CPL', value: '₹180', color: 'text-meta-blue' },
              { label: 'CTR', value: '4.6%', color: 'text-yellow-400' },
              { label: 'LEADS', value: '847', color: 'text-white' },
            ].map((m) => (
              <div key={m.label} className="bg-white/5 rounded p-2">
                <p className="text-white/30 text-[7px]">{m.label}</p>
                <p className={`font-bold text-xs ${m.color}`}>{m.value}</p>
              </div>
            ))}
          </div>

          {/* Mini chart */}
          <div className="mt-2 bg-white/5 rounded-lg p-2">
            <p className="text-white/30 text-[7px] mb-2">LEADS / WEEK</p>
            <div className="flex items-end gap-1 h-8">
              {[20, 45, 30, 70, 55, 85, 100].map((h, i) => (
                <div
                  key={i}
                  className="flex-1 bg-meta-blue/60 rounded-sm"
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Home bar */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-20 h-1 bg-white/20 rounded-full" />
    </div>
  );
}

function ROASCard() {
  return (
    <div className="bg-white rounded-xl shadow-2xl p-4 w-44">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-meta-blue/10 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-meta-blue" />
          </div>
          <span className="font-inter text-xs text-brand-text font-medium">ROAS</span>
        </div>
        <span className="text-green-500 text-xs font-semibold">+240%</span>
      </div>
      <p className="font-montserrat font-bold text-2xl text-midnight">10.4x</p>
      <p className="text-gray-400 text-xs mt-1">Return on Ad Spend</p>
      <div className="mt-3 flex items-end gap-0.5 h-6">
        {[30, 50, 40, 70, 60, 80, 100].map((h, i) => (
          <div key={i} className="flex-1 bg-meta-blue/20 rounded-sm" style={{ height: `${h}%` }} />
        ))}
      </div>
    </div>
  );
}

function LeadNotif() {
  return (
    <div className="bg-midnight rounded-xl p-3.5 w-52 shadow-2xl border border-white/10">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-full bg-meta-blue flex items-center justify-center flex-shrink-0">
          <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
          </svg>
        </div>
        <div>
          <p className="text-white text-xs font-semibold">New Lead Received</p>
          <p className="text-white/40 text-[10px]">Real Estate Campaign</p>
        </div>
        <div className="ml-auto">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
        </div>
      </div>
    </div>
  );
}

function MessengerNotif() {
  return (
    <div className="bg-white rounded-xl shadow-xl p-3 w-48 border border-gray-100">
      <div className="flex items-center gap-2">
        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0">
          <svg viewBox="0 0 24 24" fill="white" className="w-3.5 h-3.5">
            <path d="M12 2C6.36 2 2 6.13 2 11.7c0 2.91 1.19 5.44 3.14 7.17.16.13.26.35.26.56l.05 1.78c.03.54.59.88 1.09.65l1.99-.88c.17-.08.36-.09.53-.04C9.92 21.23 10.94 21.4 12 21.4c5.64 0 10-4.13 10-9.7C22 6.13 17.64 2 12 2z"/>
          </svg>
        </div>
        <div>
          <p className="text-xs font-semibold text-brand-text">Priya S.</p>
          <p className="text-gray-400 text-[9px]">Interested in your service</p>
        </div>
      </div>
    </div>
  );
}

// ─── Metrics Section ──────────────────────────────────────────────────────────

function MetricItem({ value, suffix, label }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <div ref={ref} className="text-center">
      <div className="font-montserrat font-bold text-4xl lg:text-5xl text-midnight mb-1">
        {inView ? value : '0'}{suffix}
      </div>
      <p className="font-inter text-sm text-gray-500">{label}</p>
    </div>
  );
}

// ─── Why Supreme Ads ──────────────────────────────────────────────────────────

const capabilities = [
  {
    title: 'Meta Ads Specialists',
    desc: 'Dedicated experts who live and breathe Meta advertising — not generalists juggling ten platforms.',
  },
  {
    title: 'Creative Testing',
    desc: 'Systematic A/B testing of ad creatives, hooks and formats to find what converts at scale.',
  },
  {
    title: 'Audience Research',
    desc: 'Deep-dive audience analysis to find the exact people ready to buy what you sell.',
  },
  {
    title: 'Pixel & Conversion API',
    desc: 'Server-side tracking setup that captures leads and purchases even with iOS restrictions.',
  },
  {
    title: 'WhatsApp Automation',
    desc: 'Instant lead engagement via WhatsApp — strike while intent is highest.',
  },
  {
    title: 'Retargeting Funnels',
    desc: 'Multi-stage remarketing that brings back visitors and nurtures them to conversion.',
  },
  {
    title: 'Catalog Ads',
    desc: 'Dynamic product catalog campaigns that show the right product to the right buyer automatically.',
  },
  {
    title: 'Transparent Reporting',
    desc: 'Weekly performance dashboards with no fluff — revenue attributed, leads tracked, CPL reported.',
  },
];

// ─── Industry Marquee ─────────────────────────────────────────────────────────

const marqueeItems = [
  'Real Estate', 'Jewellery Stores', 'Hospitals & Clinics', 'Coaching Institutes',
  'Fitness Centres', 'Ecommerce Brands', 'Travel Agencies', 'Interior Designers',
  'Salons & Studios', 'Automobile Dealers', 'B2B Businesses', 'Insurance Consultants',
];

function FadeUp({ children, delay = 0, className = '' }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 28 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export default function Home() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroY = useTransform(scrollYProgress, [0, 1], ['0%', '30%']);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  // Check for hero media
  const [heroMedia, setHeroMedia] = useState('none'); // 'video' | 'image' | 'none'

  return (
    <main>
      {/* ─── HERO ──────────────────────────────────────────────────── */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center bg-midnight overflow-hidden"
      >
        {/* Background */}
        <motion.div className="absolute inset-0" style={{ y: heroY }}>
          {/* Gradient base */}
          <div className="absolute inset-0 bg-gradient-to-br from-midnight via-[#0d1e3d] to-midnight" />

          {/* Hero image (replaceable) */}
          <img
            src="/images/hero.jpg"
            alt=""
            className="absolute inset-0 w-full h-full object-cover opacity-20"
            onError={(e) => { e.target.style.display = 'none'; }}
          />

          {/* Hero video (replaceable) */}
          <video
            autoPlay muted loop playsInline
            className="absolute inset-0 w-full h-full object-cover opacity-20"
            style={{ display: 'none' }}
            onLoadedData={(e) => { e.target.style.display = 'block'; }}
          >
            <source src="/videos/hero.mp4" type="video/mp4" />
          </video>

          {/* Grid overlay */}
          <div
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage: 'linear-gradient(rgba(255,255,255,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.08) 1px, transparent 1px)',
              backgroundSize: '60px 60px',
            }}
          />

          {/* Glow orb */}
          <div className="absolute top-1/3 right-1/4 w-96 h-96 rounded-full bg-meta-blue/15 blur-[100px] glow-animate" />
          <div className="absolute bottom-1/4 left-1/4 w-64 h-64 rounded-full bg-blue-400/10 blur-[80px] glow-animate" style={{ animationDelay: '1.5s' }} />
        </motion.div>

        {/* Content */}
        <motion.div
          className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 pt-20 pb-16 grid lg:grid-cols-2 gap-16 items-center"
          style={{ opacity: heroOpacity }}
        >
          {/* Left: Text */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex items-center gap-3 mb-8"
            >
              <div className="w-1 h-8 bg-meta-blue" />
              <span className="font-inter text-white/50 text-xs tracking-[0.2em] uppercase">
                Meta Advertising Specialists
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.35 }}
              className="font-montserrat font-bold text-5xl lg:text-7xl text-white leading-[1.0] mb-6"
            >
              TURN<br />
              <span className="text-meta-blue">CLICKS</span><br />
              INTO<br />
              CUSTOMERS
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="font-inter text-white/60 text-base leading-relaxed max-w-md mb-10"
            >
              Meta campaigns built for businesses that want more than impressions. We help brands acquire customers, scale revenue and unlock profitable growth through strategic Meta advertising.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.65 }}
              className="flex flex-wrap gap-4"
            >
              <Link to="/contact" className="btn-primary">
                Book Growth Audit
              </Link>
              <Link to="/case-studies" className="btn-outline">
                View Success Stories
              </Link>
            </motion.div>

            {/* Social proof */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.9 }}
              className="mt-12 flex items-center gap-8 border-t border-white/10 pt-8"
            >
              {[
                { val: '200M+', lbl: 'Impressions' },
                { val: '₹50Cr+', lbl: 'Revenue' },
                { val: '10X+', lbl: 'ROAS' },
              ].map((s) => (
                <div key={s.lbl}>
                  <p className="font-montserrat font-bold text-xl text-white">{s.val}</p>
                  <p className="font-inter text-white/40 text-xs">{s.lbl}</p>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right: Visual stack */}
          <div className="relative hidden lg:flex items-center justify-center h-[520px]">
            {/* Meta logo large */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="absolute w-32 h-32 opacity-20 top-8 right-16"
            >
              <MetaLogo />
            </motion.div>

            {/* Phone */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="absolute right-8 top-1/2 -translate-y-1/2 float-animate"
            >
              <PhoneMockup />
            </motion.div>

            {/* ROAS card */}
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.65 }}
              className="absolute left-0 top-1/4 float-slow"
            >
              <ROASCard />
            </motion.div>

            {/* Lead notification */}
            <motion.div
              className="absolute left-4 bottom-24 notif-animate"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
            >
              <LeadNotif />
            </motion.div>

            {/* Messenger notif */}
            <motion.div
              className="absolute right-4 top-16 notif-animate-delay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2 }}
            >
              <MessengerNotif />
            </motion.div>

            {/* CPL card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.8 }}
              className="absolute left-12 top-12 bg-midnight/80 border border-white/10 rounded-xl p-3 w-36 backdrop-blur-sm float-animate"
              style={{ animationDelay: '2s' }}
            >
              <p className="text-white/40 text-[9px] uppercase tracking-wider mb-1">Cost Per Lead</p>
              <p className="font-montserrat font-bold text-white text-xl">₹180</p>
              <p className="text-green-400 text-xs mt-1">-62% vs. avg</p>
            </motion.div>
          </div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
        >
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="flex flex-col items-center gap-2"
          >
            <div className="w-px h-10 bg-gradient-to-b from-white/30 to-transparent" />
          </motion.div>
        </motion.div>
      </section>

      {/* ─── INDUSTRY MARQUEE ──────────────────────────────────────── */}
      <section className="py-6 bg-light-bg border-y border-gray-100 overflow-hidden">
        <div className="flex whitespace-nowrap">
          <div className="animate-marquee flex items-center gap-0 flex-shrink-0">
            {[...marqueeItems, ...marqueeItems].map((item, i) => (
              <span key={i} className="inline-flex items-center gap-6 px-8">
                <span className="font-inter text-sm text-gray-500 font-medium">{item}</span>
                <span className="w-1 h-1 rounded-full bg-meta-blue flex-shrink-0" />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ─── METRICS ───────────────────────────────────────────────── */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <FadeUp className="text-center mb-16">
            <p className="section-label">Proof of Performance</p>
            <h2 className="section-heading text-3xl lg:text-4xl">
              Numbers That Define Our Work
            </h2>
          </FadeUp>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
            {[
              { display: '200M+', label: 'Impressions Delivered' },
              { display: '₹50Cr+', label: 'Revenue Influenced' },
              { display: '10X+', label: 'ROAS In Selected Campaigns' },
              { display: '500+', label: 'Campaigns Managed' },
            ].map((m, i) => (
              <FadeUp key={m.label} delay={i * 0.1}>
                <div className="text-center border-l border-gray-100 first:border-0 pl-8 first:pl-0">
                  <p className="font-montserrat font-bold text-4xl lg:text-5xl text-midnight mb-2">
                    {m.display}
                  </p>
                  <p className="font-inter text-sm text-gray-500">{m.label}</p>
                </div>
              </FadeUp>
            ))}
          </div>

          <FadeUp className="mt-10 text-center">
            <p className="font-inter text-xs text-gray-400 italic">
              Performance depends on industry, offer quality and market conditions.
            </p>
          </FadeUp>
        </div>
      </section>

      {/* ─── WHY SUPREME ADS ───────────────────────────────────────── */}
      <section className="py-20 lg:py-28 bg-light-bg">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div className="lg:sticky lg:top-28">
              <FadeUp>
                <p className="section-label">Why Supreme Ads</p>
                <h2 className="section-heading text-3xl lg:text-4xl mb-6">
                  Built for Businesses<br />That Demand Results
                </h2>
                <p className="font-inter text-gray-500 text-base leading-relaxed mb-8">
                  We are not a full-service agency that dabbles in Meta. Every strategy, creative, and rupee of ad spend is focused on one outcome: acquiring customers profitably.
                </p>
                <Link to="/contact" className="btn-primary inline-block">
                  Book Growth Audit
                </Link>
              </FadeUp>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {capabilities.map((cap, i) => (
                <FadeUp key={cap.title} delay={i * 0.06}>
                  <div className="bg-white p-6 border border-gray-100 hover:border-meta-blue/30 hover:shadow-lg transition-all duration-300 group">
                    <div className="w-8 h-8 bg-meta-blue/10 flex items-center justify-center mb-4 group-hover:bg-meta-blue/20 transition-colors">
                      <div className="w-2 h-2 rounded-full bg-meta-blue" />
                    </div>
                    <h3 className="font-montserrat font-semibold text-sm text-midnight mb-2">
                      {cap.title}
                    </h3>
                    <p className="font-inter text-xs text-gray-500 leading-relaxed">
                      {cap.desc}
                    </p>
                  </div>
                </FadeUp>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ─── CTA BAND ──────────────────────────────────────────────── */}
      <section className="py-20 bg-midnight">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <FadeUp>
            <p className="section-label text-meta-blue">Ready to Scale?</p>
            <h2 className="font-montserrat font-bold text-3xl lg:text-5xl text-white mb-6">
              Your Competitors Are Already Running Meta Ads.
            </h2>
            <p className="font-inter text-white/50 text-base mb-10 max-w-xl mx-auto">
              Book a free Growth Audit and discover exactly how Supreme Ads can drive customer acquisition for your business.
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link to="/contact" className="btn-primary">
                Book Growth Audit
              </Link>
              <a
                href="https://wa.me/919667173693"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-outline inline-flex items-center gap-2"
              >
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white" xmlns="http://www.w3.org/2000/svg">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                Chat on WhatsApp
              </a>
            </div>
          </FadeUp>
        </div>
      </section>
    </main>
  );
}
