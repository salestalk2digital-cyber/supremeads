import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView } from 'framer-motion';

const industries = [
  { name: 'Real Estate', sub: 'Builders & Channel Partners', tag: 'Lead Gen' },
  { name: 'Event Planners', sub: 'Weddings & Corporate Events', tag: 'Bookings' },
  { name: 'B2B Businesses', sub: 'Enterprise & SME', tag: 'Lead Gen' },
  { name: 'B2C Brands', sub: 'Consumer Products', tag: 'Sales' },
  { name: 'Perfume & Attar', sub: 'Premium Fragrance Brands', tag: 'E-Commerce' },
  { name: 'Fashion & Boutique', sub: 'Designers & Boutique Owners', tag: 'Sales' },
  { name: 'Private Theatres', sub: 'Experience Venues', tag: 'Bookings' },
  { name: 'Beauty Studios', sub: 'MUAs, Salons & Studios', tag: 'Appointments' },
  { name: 'Coaching Institutes', sub: 'Courses & IELTS Centres', tag: 'Enrolments' },
  { name: 'Schools', sub: 'Admissions & Institutions', tag: 'Admissions' },
  { name: 'Hospitals & Clinics', sub: 'Healthcare Providers', tag: 'Consultations' },
  { name: 'Restaurants', sub: 'Dine-in & Delivery', tag: 'Footfall' },
  { name: 'Travel Agencies', sub: 'Tours & Holiday Packages', tag: 'Bookings' },
  { name: 'Architecture & Interiors', sub: 'Designers & Studios', tag: 'Lead Gen' },
  { name: 'Car Detailing', sub: 'Ceramic Coating Studios', tag: 'Appointments' },
  { name: 'Automobile Dealers', sub: 'New & Used Car Dealerships', tag: 'Inquiries' },
  { name: 'Ecommerce Brands', sub: 'DTC & Marketplace', tag: 'ROAS' },
  { name: 'Jewellery Stores', sub: 'Fine & Fashion Jewellery', tag: 'Sales' },
  { name: 'Furniture Stores', sub: 'Home & Office Furniture', tag: 'Sales' },
  { name: 'Fitness Centres', sub: 'Gyms & Training Studios', tag: 'Memberships' },
  { name: 'CA & Finance Firms', sub: 'Accounting & Consulting', tag: 'Lead Gen' },
  { name: 'Insurance', sub: 'Advisors & Consultants', tag: 'Lead Gen' },
  { name: 'Study Abroad', sub: 'Education Consultants', tag: 'Lead Gen' },
  { name: 'Pet Stores', sub: 'Products & Services', tag: 'Sales' },
  { name: 'Electronics Stores', sub: 'Consumer Electronics', tag: 'Sales' },
];

function FadeUp({ children, delay = 0, className = '' }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

const tagColors = {
  'Lead Gen': 'bg-blue-50 text-meta-blue',
  'Sales': 'bg-green-50 text-green-700',
  'E-Commerce': 'bg-purple-50 text-purple-700',
  'ROAS': 'bg-orange-50 text-orange-700',
  'Bookings': 'bg-yellow-50 text-yellow-700',
  'Appointments': 'bg-pink-50 text-pink-700',
  'Admissions': 'bg-indigo-50 text-indigo-700',
  'Enrolments': 'bg-teal-50 text-teal-700',
  'Consultations': 'bg-red-50 text-red-700',
  'Footfall': 'bg-amber-50 text-amber-700',
  'Inquiries': 'bg-cyan-50 text-cyan-700',
  'Memberships': 'bg-emerald-50 text-emerald-700',
};

export default function Industries() {
  const [search, setSearch] = useState('');

  const filtered = industries.filter(
    (ind) =>
      ind.name.toLowerCase().includes(search.toLowerCase()) ||
      ind.sub.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <main className="pt-20">
      {/* Header */}
      <section className="bg-midnight py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <p className="section-label text-meta-blue mb-4">Industries We Serve</p>
            <h1 className="font-montserrat font-bold text-4xl lg:text-6xl text-white mb-6 leading-tight">
              We've Driven Growth<br />Across Every Sector
            </h1>
            <p className="font-inter text-white/50 text-base max-w-xl leading-relaxed">
              From real estate to retail, our Meta advertising strategies are built around the specific buying behaviour of your industry's customers.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Industries Grid */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          {/* Search */}
          <FadeUp className="mb-10">
            <div className="relative max-w-sm">
              <input
                type="text"
                placeholder="Search your industry..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full border border-gray-200 font-inter text-sm px-4 py-3 pl-10 focus:outline-none focus:border-meta-blue transition-colors"
              />
              <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
          </FadeUp>

          {filtered.length === 0 ? (
            <div className="text-center py-16">
              <p className="font-inter text-gray-400 text-sm">No industries found. Try a different search.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filtered.map((industry, i) => (
                <FadeUp key={industry.name} delay={Math.min(i * 0.04, 0.4)}>
                  <Link
                    to="/contact"
                    className="group block bg-white border border-gray-100 hover:border-meta-blue/30 hover:shadow-xl transition-all duration-300 p-6 relative overflow-hidden"
                  >
                    {/* Hover accent */}
                    <div className="absolute inset-x-0 top-0 h-0.5 bg-meta-blue scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />

                    <div className="flex items-start justify-between mb-4">
                      <div className="w-10 h-10 bg-light-bg flex items-center justify-center group-hover:bg-meta-blue/10 transition-colors">
                        <div className="w-3 h-3 rounded-full bg-meta-blue/30 group-hover:bg-meta-blue transition-colors" />
                      </div>
                      <span className={`text-[10px] font-inter font-medium px-2 py-1 rounded-sm ${tagColors[industry.tag] || 'bg-gray-100 text-gray-600'}`}>
                        {industry.tag}
                      </span>
                    </div>

                    <h3 className="font-montserrat font-semibold text-midnight text-sm mb-1 group-hover:text-meta-blue transition-colors">
                      {industry.name}
                    </h3>
                    <p className="font-inter text-gray-400 text-xs">{industry.sub}</p>

                    <div className="mt-4 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="font-inter text-meta-blue text-xs font-medium">Get Started</span>
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-3 h-3 text-meta-blue" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M5 12h14M12 5l7 7-7 7"/>
                      </svg>
                    </div>
                  </Link>
                </FadeUp>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-light-bg">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center">
          <FadeUp>
            <p className="section-label">Don't See Your Industry?</p>
            <h2 className="section-heading text-2xl lg:text-3xl mb-4 text-midnight">
              If Your Customers Are on Meta, We Can Reach Them
            </h2>
            <p className="font-inter text-gray-500 text-sm mb-8">
              We've helped businesses in dozens of verticals. Let's talk about yours.
            </p>
            <Link to="/contact" className="btn-primary inline-block">
              Book a Free Consultation
            </Link>
          </FadeUp>
        </div>
      </section>
    </main>
  );
}
