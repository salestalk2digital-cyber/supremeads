import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';

function FadeUp({ children, delay = 0, className = '' }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function ThankYouPopup({ onClose }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        className="bg-white w-full max-w-md text-center"
      >
        {/* Top accent */}
        <div className="h-1 bg-meta-blue w-full" />

        <div className="px-8 py-12">
          {/* Icon */}
          <div className="w-16 h-16 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 text-green-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>

          <h2 className="font-montserrat font-bold text-2xl text-midnight mb-3">
            Thank You
          </h2>
          <p className="font-inter text-gray-500 text-sm leading-relaxed mb-8">
            Our Meta Ads Growth Team will contact you shortly.
          </p>

          <div className="flex flex-col gap-3">
            <a
              href="https://wa.me/919667173693"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-[#25D366] text-white font-montserrat font-semibold text-sm py-3.5 hover:bg-green-500 transition-colors"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              Chat On WhatsApp
            </a>

            <Link
              to="/contact"
              onClick={onClose}
              className="flex items-center justify-center font-montserrat font-semibold text-sm py-3.5 border border-midnight/20 text-midnight hover:bg-midnight hover:text-white transition-all duration-300"
            >
              Book Growth Audit
            </Link>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

const budgetOptions = [
  'Under ₹20,000/month',
  '₹20,000 – ₹50,000/month',
  '₹50,000 – ₹1,00,000/month',
  '₹1,00,000 – ₹5,00,000/month',
  '₹5,00,000+/month',
  'Not Sure Yet',
];

const industryOptions = [
  'Real Estate', 'Ecommerce', 'Coaching / Education', 'Healthcare / Hospital',
  'Salon & Beauty', 'Restaurant & Food', 'Travel Agency', 'Automobile', 'Interior Design',
  'Fashion & Apparel', 'Jewellery', 'Finance & Insurance', 'Fitness', 'B2B Services', 'Other',
];

const INITIAL = {
  name: '', phone: '', email: '', business: '',
  industry: '', budget: '', message: '',
};

export default function Contact() {
  const [form, setForm] = useState(INITIAL);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showThanks, setShowThanks] = useState(false);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
  };

  const sendEmailNotification = async (data) => {
    // EmailJS or similar could be integrated here.
    // Placeholder — configure your own email service endpoint.
    try {
      await fetch('https://formspree.io/f/YOUR_FORM_ID', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({
          to: 'amanbhambhani33@gmail.com',
          subject: 'New Supreme Ads Lead',
          ...data,
        }),
      });
    } catch (e) {
      // Silent fail on email — lead already saved to Firestore
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const required = ['name', 'phone', 'email', 'business', 'industry', 'budget'];
    for (const field of required) {
      if (!form[field]) {
        setError('Please fill all required fields.');
        return;
      }
    }

    setLoading(true);
    try {
      await addDoc(collection(db, 'enquiries'), {
        name: form.name,
        phone: form.phone,
        email: form.email,
        business: form.business,
        industry: form.industry,
        budget: form.budget,
        message: form.message,
        createdAt: serverTimestamp(),
      });

      await sendEmailNotification(form);
      setForm(INITIAL);
      setShowThanks(true);
    } catch (err) {
      console.error(err);
      setError('Something went wrong. Please try again or message us on WhatsApp.');
    } finally {
      setLoading(false);
    }
  };

  const inputClass = `w-full border border-gray-200 focus:border-meta-blue focus:outline-none font-inter text-sm text-brand-text placeholder-gray-400 px-4 py-3.5 transition-colors bg-white`;
  const labelClass = `block font-inter font-medium text-xs text-gray-600 mb-2 uppercase tracking-wider`;

  return (
    <main className="pt-20">
      {/* Header */}
      <section className="bg-midnight py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <p className="section-label text-meta-blue mb-4">Get in Touch</p>
            <h1 className="font-montserrat font-bold text-4xl lg:text-6xl text-white mb-6 leading-tight">
              Let's Talk About<br />Your Growth
            </h1>
            <p className="font-inter text-white/50 text-base max-w-md leading-relaxed">
              Fill the form and our team will reach out within one business day for a free Growth Audit.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 lg:py-24 bg-light-bg">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-12 lg:gap-20 items-start">
            {/* Left sidebar */}
            <div className="lg:col-span-2">
              <FadeUp>
                <h2 className="font-montserrat font-bold text-2xl text-midnight mb-6">
                  What Happens Next
                </h2>

                <div className="space-y-6 mb-10">
                  {[
                    {
                      step: '01',
                      title: 'Growth Audit Call',
                      desc: 'We review your current Meta presence, funnel and audience setup.',
                    },
                    {
                      step: '02',
                      title: 'Custom Strategy',
                      desc: 'You receive a tailored Meta ad strategy specific to your business goals.',
                    },
                    {
                      step: '03',
                      title: 'Campaign Launch',
                      desc: 'We launch, test and scale your campaigns with weekly reporting.',
                    },
                  ].map((item) => (
                    <div key={item.step} className="flex gap-4">
                      <div className="flex-shrink-0 font-montserrat font-bold text-meta-blue text-xs tracking-wider mt-0.5">
                        {item.step}
                      </div>
                      <div>
                        <p className="font-montserrat font-semibold text-midnight text-sm mb-1">
                          {item.title}
                        </p>
                        <p className="font-inter text-gray-500 text-xs leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Contact info */}
                <div className="border-t border-gray-200 pt-8 space-y-4">
                  <a
                    href="https://wa.me/919667173693"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 group"
                  >
                    <div className="w-10 h-10 bg-[#25D366]/10 flex items-center justify-center group-hover:bg-[#25D366]/20 transition-colors">
                      <svg viewBox="0 0 24 24" className="w-5 h-5 fill-[#25D366]">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                    </div>
                    <div>
                      <p className="font-inter text-xs text-gray-400 uppercase tracking-wider mb-0.5">WhatsApp</p>
                      <p className="font-inter font-medium text-sm text-midnight group-hover:text-meta-blue transition-colors">
                        +91 96671 73693
                      </p>
                    </div>
                  </a>

                  <a
                    href="mailto:amanbhambhani33@gmail.com"
                    className="flex items-center gap-3 group"
                  >
                    <div className="w-10 h-10 bg-meta-blue/10 flex items-center justify-center group-hover:bg-meta-blue/20 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 text-meta-blue" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                      </svg>
                    </div>
                    <div>
                      <p className="font-inter text-xs text-gray-400 uppercase tracking-wider mb-0.5">Email</p>
                      <p className="font-inter font-medium text-sm text-midnight group-hover:text-meta-blue transition-colors">
                        amanbhambhani33@gmail.com
                      </p>
                    </div>
                  </a>
                </div>
              </FadeUp>
            </div>

            {/* Form */}
            <div className="lg:col-span-3">
              <FadeUp delay={0.1}>
                <div className="bg-white border border-gray-100 p-8 lg:p-10">
                  <h3 className="font-montserrat font-semibold text-midnight text-lg mb-8">
                    Book Your Free Growth Audit
                  </h3>

                  <form onSubmit={handleSubmit} noValidate>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                      <div>
                        <label className={labelClass}>Full Name *</label>
                        <input
                          name="name"
                          type="text"
                          value={form.name}
                          onChange={handleChange}
                          placeholder="Rahul Sharma"
                          className={inputClass}
                        />
                      </div>
                      <div>
                        <label className={labelClass}>Phone Number *</label>
                        <input
                          name="phone"
                          type="tel"
                          value={form.phone}
                          onChange={handleChange}
                          placeholder="+91 98765 43210"
                          className={inputClass}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                      <div>
                        <label className={labelClass}>Email Address *</label>
                        <input
                          name="email"
                          type="email"
                          value={form.email}
                          onChange={handleChange}
                          placeholder="rahul@business.com"
                          className={inputClass}
                        />
                      </div>
                      <div>
                        <label className={labelClass}>Business Name *</label>
                        <input
                          name="business"
                          type="text"
                          value={form.business}
                          onChange={handleChange}
                          placeholder="Your Business Name"
                          className={inputClass}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 mb-5">
                      <div>
                        <label className={labelClass}>Industry *</label>
                        <select
                          name="industry"
                          value={form.industry}
                          onChange={handleChange}
                          className={inputClass}
                        >
                          <option value="">Select your industry</option>
                          {industryOptions.map((opt) => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className={labelClass}>Monthly Meta Ads Budget *</label>
                        <select
                          name="budget"
                          value={form.budget}
                          onChange={handleChange}
                          className={inputClass}
                        >
                          <option value="">Select budget range</option>
                          {budgetOptions.map((opt) => (
                            <option key={opt} value={opt}>{opt}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="mb-6">
                      <label className={labelClass}>Message (Optional)</label>
                      <textarea
                        name="message"
                        value={form.message}
                        onChange={handleChange}
                        rows={4}
                        placeholder="Tell us about your current challenges, goals or anything you'd like us to know before the call..."
                        className={`${inputClass} resize-none`}
                      />
                    </div>

                    {error && (
                      <p className="font-inter text-red-500 text-xs mb-4">{error}</p>
                    )}

                    <button
                      type="submit"
                      disabled={loading}
                      className="w-full bg-meta-blue text-white font-montserrat font-semibold text-sm tracking-wide py-4 hover:bg-blue-700 transition-colors disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                      {loading ? 'Submitting...' : 'Book Growth Audit'}
                    </button>

                    <p className="font-inter text-gray-400 text-xs text-center mt-4">
                      No commitment. No spam. Just a focused conversation about your growth.
                    </p>
                  </form>
                </div>
              </FadeUp>
            </div>
          </div>
        </div>
      </section>

      {/* Thank you popup */}
      <AnimatePresence>
        {showThanks && <ThankYouPopup onClose={() => setShowThanks(false)} />}
      </AnimatePresence>
    </main>
  );
}
