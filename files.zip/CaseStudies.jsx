import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, AnimatePresence } from 'framer-motion';

const caseStudies = [
  {
    id: 1,
    industry: 'Real Estate',
    client: 'Luxury Apartment Developer',
    goal: 'Qualified Buyer Leads',
    adSpend: '₹4,20,000',
    leads: '312',
    cpl: '₹1,346',
    revenue: '₹18.5 Cr',
    roas: '44x',
    summary: 'A Noida-based luxury apartment developer was struggling with expensive walk-in leads from traditional channels. We restructured their Meta funnel with lookalike audiences based on past buyers, layered interest targeting and a WhatsApp lead form campaign.',
    result: 'Sold 14 apartments at ₹1.2–1.8 Cr per unit within 90 days of campaign launch.',
    tags: ['Lead Gen', 'WhatsApp', 'Lookalike'],
  },
  {
    id: 2,
    industry: 'Coaching Institute',
    client: 'UPSC & Banking Coaching Centre',
    goal: 'Enrolments for Batch Seats',
    adSpend: '₹85,000',
    leads: '628',
    cpl: '₹135',
    revenue: '₹72 L',
    roas: '8.5x',
    summary: 'The institute needed to fill 3 batches within 45 days. We deployed urgency-driven video ads targeting Class 12 pass-outs and graduates in tier-2 cities, with remarketing to website visitors and a dedicated lead magnet (free demo class).',
    result: 'All 3 batches filled with a waitlist of 60+ students. CPL dropped 58% versus previous campaigns.',
    tags: ['Video Ads', 'Remarketing', 'Lead Magnet'],
  },
  {
    id: 3,
    industry: 'Ecommerce',
    client: 'Premium Skincare Brand',
    goal: 'Direct Purchases & ROAS',
    adSpend: '₹2,10,000',
    leads: 'N/A',
    cpl: 'N/A',
    revenue: '₹21.6 L',
    roas: '10.3x',
    summary: 'A D2C skincare brand with strong product-market fit but poor Meta performance. We rebuilt their entire funnel: catalog campaigns at TOF, testimonial video ads for remarketing, and a checkout abandonment sequence via Messenger.',
    result: '10.3x ROAS sustained over 60 days. Revenue grew 310% versus the same period last year.',
    tags: ['Catalog Ads', 'Retargeting', 'D2C'],
  },
  {
    id: 4,
    industry: 'Salon & Beauty Studio',
    client: 'Premium Bridal Studio Chain',
    goal: 'Bridal Booking Inquiries',
    adSpend: '₹62,000',
    leads: '184',
    cpl: '₹337',
    revenue: '₹28 L',
    roas: '45x',
    summary: 'Three-location bridal studio needed to fill the wedding season calendar in Q1. We ran hyperlocal radius campaigns with before/after creative formats and an instant form tied to WhatsApp follow-up automation.',
    result: 'Calendar booked out 3 months in advance. 184 qualified bridal inquiries in 30 days.',
    tags: ['Hyperlocal', 'WhatsApp', 'Instant Forms'],
  },
  {
    id: 5,
    industry: 'Hospital',
    client: 'Multi-Specialty Hospital',
    goal: 'OPD Consultation Bookings',
    adSpend: '₹1,50,000',
    leads: '1,240',
    cpl: '₹121',
    revenue: '₹93 L',
    roas: '6.2x',
    summary: 'A Delhi NCR hospital wanted to grow their orthopaedic and cardiology OPD. We ran condition-specific campaigns targeting caregivers and patients aged 40+, with a free consultation offer driving form completions.',
    result: '1,240 OPD bookings in 60 days. 6.2x return on ad spend across departments.',
    tags: ['Healthcare', 'Lead Forms', 'Age Targeting'],
  },
  {
    id: 6,
    industry: 'Automobile',
    client: 'Used Car Dealership',
    goal: 'Test Drive Inquiries',
    adSpend: '₹95,000',
    leads: '430',
    cpl: '₹221',
    revenue: '₹1.4 Cr',
    roas: '14.7x',
    summary: 'A premium pre-owned car dealership was relying on OLX and walk-ins. We deployed catalog ads showing their live inventory, targeted in-market buyers using Meta\'s Automotive audience segments, and set up a rapid WhatsApp response workflow.',
    result: '430 qualified inquiries. 47 cars sold. Average deal value ₹2.9 L.',
    tags: ['Catalog Ads', 'Automotive', 'WhatsApp'],
  },
];

function FadeUp({ children, delay = 0, className = '' }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-50px' });
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function CaseStudyModal({ cs, onClose }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.3 }}
        className="bg-white w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-midnight px-8 py-8 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 text-white/40 hover:text-white transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
          <span className="inline-block bg-meta-blue text-white text-xs font-inter font-medium px-3 py-1 mb-4">
            {cs.industry}
          </span>
          <h2 className="font-montserrat font-bold text-2xl text-white mb-2">{cs.client}</h2>
          <p className="font-inter text-white/50 text-sm">Goal: {cs.goal}</p>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-3 border-b border-gray-100">
          {[
            { label: 'Ad Spend', val: cs.adSpend },
            { label: 'Leads', val: cs.leads },
            { label: 'ROAS', val: cs.roas },
          ].map((m) => (
            <div key={m.label} className="px-6 py-5 border-r border-gray-100 last:border-0">
              <p className="font-inter text-gray-400 text-xs mb-1">{m.label}</p>
              <p className="font-montserrat font-bold text-midnight text-xl">{m.val}</p>
            </div>
          ))}
        </div>

        {/* More metrics */}
        <div className="grid grid-cols-2 border-b border-gray-100">
          {[
            { label: 'Cost Per Lead', val: cs.cpl },
            { label: 'Revenue', val: cs.revenue },
          ].map((m) => (
            <div key={m.label} className="px-6 py-5 border-r border-gray-100 last:border-0">
              <p className="font-inter text-gray-400 text-xs mb-1">{m.label}</p>
              <p className="font-montserrat font-bold text-midnight text-xl">{m.val}</p>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="px-8 py-6">
          <h3 className="font-montserrat font-semibold text-midnight text-sm mb-3">The Strategy</h3>
          <p className="font-inter text-gray-500 text-sm leading-relaxed mb-6">{cs.summary}</p>

          <h3 className="font-montserrat font-semibold text-midnight text-sm mb-3">The Result</h3>
          <p className="font-inter text-gray-500 text-sm leading-relaxed mb-6">{cs.result}</p>

          <div className="flex flex-wrap gap-2 mb-8">
            {cs.tags.map((tag) => (
              <span key={tag} className="font-inter text-xs text-meta-blue bg-blue-50 px-3 py-1">
                {tag}
              </span>
            ))}
          </div>

          <Link
            to="/contact"
            onClick={onClose}
            className="btn-primary w-full text-center block"
          >
            Get Similar Results for Your Business
          </Link>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function CaseStudies() {
  const [active, setActive] = useState(null);

  return (
    <main className="pt-20">
      {/* Header */}
      <section className="bg-midnight py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <p className="section-label text-meta-blue mb-4">Proven Results</p>
            <h1 className="font-montserrat font-bold text-4xl lg:text-6xl text-white mb-6 leading-tight">
              Campaigns That<br />Actually Performed
            </h1>
            <p className="font-inter text-white/50 text-base max-w-xl leading-relaxed">
              Real numbers from real campaigns. No vanity metrics, no inflated reach figures — revenue, leads and cost per acquisition.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Case Studies Grid */}
      <section className="py-16 lg:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {caseStudies.map((cs, i) => (
              <FadeUp key={cs.id} delay={i * 0.08}>
                <div className="border border-gray-100 hover:border-gray-200 hover:shadow-xl transition-all duration-300 group flex flex-col h-full">
                  {/* Card header */}
                  <div className="bg-light-bg px-6 py-5 border-b border-gray-100">
                    <div className="flex items-center justify-between mb-3">
                      <span className="bg-meta-blue text-white text-[10px] font-inter font-medium px-2.5 py-1 tracking-wide uppercase">
                        {cs.industry}
                      </span>
                      <span className="font-inter text-xs text-gray-400">{cs.goal}</span>
                    </div>
                    <h3 className="font-montserrat font-semibold text-midnight text-base">{cs.client}</h3>
                  </div>

                  {/* Metrics */}
                  <div className="grid grid-cols-2 border-b border-gray-100 flex-shrink-0">
                    {[
                      { label: 'Ad Spend', val: cs.adSpend },
                      { label: 'ROAS', val: cs.roas, highlight: true },
                      { label: 'Leads', val: cs.leads },
                      { label: 'Cost Per Lead', val: cs.cpl },
                    ].map((m) => (
                      <div key={m.label} className="px-5 py-4 border-r border-b border-gray-100 last:border-r-0 even:border-r-0">
                        <p className="font-inter text-gray-400 text-[10px] mb-1 uppercase tracking-wide">{m.label}</p>
                        <p className={`font-montserrat font-bold text-lg ${m.highlight ? 'text-meta-blue' : 'text-midnight'}`}>
                          {m.val}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Revenue highlight */}
                  <div className="px-6 py-4 flex items-center justify-between border-b border-gray-100">
                    <span className="font-inter text-sm text-gray-500">Revenue</span>
                    <span className="font-montserrat font-bold text-xl text-green-600">{cs.revenue}</span>
                  </div>

                  {/* Action */}
                  <div className="px-6 py-5 mt-auto">
                    <button
                      onClick={() => setActive(cs)}
                      className="w-full font-montserrat font-semibold text-xs tracking-wide text-midnight border border-midnight/20 py-3 hover:bg-midnight hover:text-white transition-all duration-300"
                    >
                      View Full Study
                    </button>
                  </div>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-midnight">
        <div className="max-w-3xl mx-auto px-6 lg:px-8 text-center">
          <FadeUp>
            <p className="section-label text-meta-blue">Your Industry Next</p>
            <h2 className="font-montserrat font-bold text-3xl lg:text-4xl text-white mb-5">
              Ready to Build Your Own Case Study?
            </h2>
            <p className="font-inter text-white/50 text-sm mb-10 max-w-lg mx-auto">
              Book a Growth Audit and we'll map out exactly how we'd approach your Meta advertising.
            </p>
            <Link to="/contact" className="btn-primary inline-block">
              Book Growth Audit
            </Link>
          </FadeUp>
        </div>
      </section>

      {/* Modal */}
      <AnimatePresence>
        {active && <CaseStudyModal cs={active} onClose={() => setActive(null)} />}
      </AnimatePresence>
    </main>
  );
}
