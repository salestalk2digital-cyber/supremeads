import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const navLinks = [
  { label: 'Home', path: '/' },
  { label: 'Industries', path: '/industries' },
  { label: 'Case Studies', path: '/case-studies' },
  { label: 'Contact', path: '/contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  const isHome = location.pathname === '/';

  return (
    <>
      <motion.header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 nav-glass ${
          scrolled
            ? 'bg-white/95 border-b border-gray-100 shadow-sm'
            : isHome
            ? 'bg-transparent'
            : 'bg-midnight/80'
        }`}
        initial={{ y: -80 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className={`w-2 h-2 rounded-full bg-meta-blue transition-all duration-300 group-hover:scale-125`} />
              <span className={`font-montserrat font-bold text-sm tracking-[0.22em] uppercase transition-colors duration-300 ${
                scrolled ? 'text-midnight' : 'text-white'
              }`}>
                Supreme Ads
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`font-inter font-medium text-sm transition-colors duration-200 relative group ${
                    scrolled ? 'text-brand-text hover:text-meta-blue' : 'text-white/80 hover:text-white'
                  } ${location.pathname === link.path ? (scrolled ? 'text-meta-blue' : 'text-white') : ''}`}
                >
                  {link.label}
                  <span className={`absolute -bottom-0.5 left-0 h-px bg-meta-blue transition-all duration-300 ${
                    location.pathname === link.path ? 'w-full' : 'w-0 group-hover:w-full'
                  }`} />
                </Link>
              ))}
            </nav>

            {/* CTA */}
            <div className="hidden lg:flex items-center">
              <Link
                to="/contact"
                className={`font-montserrat font-semibold text-xs tracking-wide px-5 py-2.5 transition-all duration-300 ${
                  scrolled
                    ? 'bg-meta-blue text-white hover:bg-blue-700'
                    : 'bg-white text-midnight hover:bg-white/90'
                }`}
              >
                Book Growth Audit
              </Link>
            </div>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden flex flex-col gap-1.5 p-2"
              aria-label="Menu"
            >
              <span className={`block w-5 h-px transition-all duration-300 ${scrolled ? 'bg-midnight' : 'bg-white'} ${mobileOpen ? 'rotate-45 translate-y-2' : ''}`} />
              <span className={`block w-5 h-px transition-all duration-300 ${scrolled ? 'bg-midnight' : 'bg-white'} ${mobileOpen ? 'opacity-0' : ''}`} />
              <span className={`block w-5 h-px transition-all duration-300 ${scrolled ? 'bg-midnight' : 'bg-white'} ${mobileOpen ? '-rotate-45 -translate-y-2' : ''}`} />
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed top-16 left-0 right-0 z-40 bg-midnight border-t border-white/10 lg:hidden"
          >
            <div className="px-6 py-6 flex flex-col gap-5">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`font-inter font-medium text-base transition-colors ${
                    location.pathname === link.path ? 'text-meta-blue' : 'text-white/80 hover:text-white'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                to="/contact"
                className="mt-2 bg-meta-blue text-white font-montserrat font-semibold text-sm text-center py-3 tracking-wide hover:bg-blue-700 transition-colors"
              >
                Book Growth Audit
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
