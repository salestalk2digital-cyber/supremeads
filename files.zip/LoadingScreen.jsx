import React from 'react';
import { motion } from 'framer-motion';

export default function LoadingScreen() {
  return (
    <motion.div
      className="fixed inset-0 z-[9999] bg-midnight flex flex-col items-center justify-center"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center"
      >
        <div className="flex items-center gap-2 mb-8">
          <div className="w-2 h-2 rounded-full bg-meta-blue" />
          <span className="font-montserrat font-semibold text-white tracking-[0.25em] text-sm uppercase">
            Supreme Ads
          </span>
        </div>

        <div className="w-48 h-px bg-white/10 mx-auto relative overflow-hidden">
          <div className="absolute inset-y-0 left-0 bg-meta-blue loader-bar" />
        </div>

        <p className="font-inter text-white/40 text-xs mt-6 tracking-widest uppercase">
          Loading
        </p>
      </motion.div>
    </motion.div>
  );
}
