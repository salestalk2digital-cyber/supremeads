# Supreme Ads — Website

Meta advertising agency website built with React, Vite, Tailwind CSS, Framer Motion and Firebase.

## Setup

```bash
npm install
npm run dev
```

## Configuration

### 1. Firebase
Open `src/firebase.js` and replace the placeholder config with your Firebase project credentials:
```js
const firebaseConfig = {
  apiKey: "...",
  authDomain: "...",
  projectId: "...",
  ...
};
```
Create a Firestore collection called `enquiries`. All form submissions are stored there.

### 2. Email Notifications
In `src/pages/Contact.jsx`, the `sendEmailNotification` function has a placeholder for [Formspree](https://formspree.io) (free tier available). Replace `YOUR_FORM_ID` with your Formspree form ID, or swap in any email API (Resend, SendGrid, EmailJS, etc).

### 3. Hero Media
- Place your hero image at `public/images/hero.jpg`
- Place your hero video at `public/videos/hero.mp4`

Both are loaded automatically. No code changes required. If both files exist, the video takes priority (it renders on top of the image).

### 4. WhatsApp
WhatsApp number is pre-configured to `+91 96671 73693`. To change it, search for `wa.me/919667173693` across the codebase.

## Deploy to Vercel

```bash
npm run build
```
Then push to GitHub and connect the repo to Vercel. The `vercel.json` file handles SPA routing.

## Deploy to GitHub Pages

```bash
npm run build
# Push the /dist folder to gh-pages branch
```

## Pages
- `/` — Home (Hero, Metrics, Why Supreme Ads, CTA)
- `/industries` — Industries served (searchable grid)
- `/case-studies` — Campaign case studies with full study modal
- `/contact` — Contact form + Firebase storage + Thank you popup
