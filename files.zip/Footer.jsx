import React from 'react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-midnight text-white">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16 lg:py-20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-2 h-2 rounded-full bg-meta-blue" />
              <span className="font-montserrat font-bold text-sm tracking-[0.22em] uppercase">
                Supreme Ads
              </span>
            </div>
            <p className="font-inter text-white/50 text-sm leading-relaxed max-w-xs">
              Meta advertising engineered to attract, nurture and convert high-intent audiences into paying customers.
            </p>
            <a
              href="https://wa.me/919667173693"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 mt-6 font-inter text-sm text-white/60 hover:text-white transition-colors"
            >
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current text-green-400" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              +91 96671 73693
            </a>
          </div>

          {/* Pages */}
          <div>
            <p className="font-montserrat font-semibold text-xs tracking-[0.2em] uppercase text-white/30 mb-5">
              Navigation
            </p>
            <ul className="space-y-3">
              {[
                { label: 'Home', path: '/' },
                { label: 'Industries', path: '/industries' },
                { label: 'Case Studies', path: '/case-studies' },
                { label: 'Contact', path: '/contact' },
              ].map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="font-inter text-sm text-white/50 hover:text-white transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* CTA */}
          <div>
            <p className="font-montserrat font-semibold text-xs tracking-[0.2em] uppercase text-white/30 mb-5">
              Get Started
            </p>
            <p className="font-inter text-sm text-white/50 mb-5 leading-relaxed">
              Ready to turn your Meta ad spend into real business results?
            </p>
            <Link
              to="/contact"
              className="inline-block bg-meta-blue text-white font-montserrat font-semibold text-xs tracking-wide px-5 py-3 hover:bg-blue-700 transition-colors"
            >
              Book Growth Audit
            </Link>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-inter text-white/30 text-xs">
            &copy; {new Date().getFullYear()} Supreme Ads. All rights reserved.
          </p>
          <p className="font-inter text-white/20 text-xs">
            Meta Advertising Specialists
          </p>
        </div>
      </div>
    </footer>
  );
}
